import java.util.ArrayList;

public class Armazem {

    private long capacidadeMax;
    private ArrayList<Produto> itens;
    private long numItens;

    public Armazem() {
    }

    public Armazem(long getCapacidadeMax) {

    }

    public Armazem(long capacidadeMax, ArrayList<Produto> itens) {
        this.capacidadeMax = capacidadeMax;
        this.itens = itens;
    }

    public long getCapacidadeMax() {
        return capacidadeMax;
    }

    public void setCapacidadeMax(long capacidadeMax) {
        this.capacidadeMax = capacidadeMax;
    }

    public ArrayList<Produto> getItens() {
        return itens;
    }

    public void setItens(ArrayList<Produto> itens) {
        this.itens = itens;
    }

    public long getNumItens() {
        return numItens;
    }

    public void setNumItens(long numItens) {
        this.numItens = numItens;
    }

}

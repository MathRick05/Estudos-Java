import java.util.ArrayList;
import java.util.Random;

public class GeradorDeItens {
    private Random random;
    private String[] nomesPossiveis = {"Espada", "Escudo", "Poção", "Armadura", "Elmo", "Bota", "Anel", "Bracelete"};

    public GeradorDeItens(long seed) {
        this.random = new Random(seed);
    }

    public GeradorDeItens() {
        this.random = new Random();
    }

    public ArrayList<Produto> gerarItensAleatorios(int quantidade) {
        ArrayList<Produto> itens = new ArrayList<>();
        for (int i = 0; i < quantidade; i++) {
            String nomeItem = "Produto" + (i + 1);
            long pesoItem = random.nextInt(50) + 1;
            long valorItem = random.nextInt(100) + 1;
            itens.add(new Produto(nomeItem, pesoItem, valorItem));
        }
        return itens;
    }
}

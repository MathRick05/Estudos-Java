import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        String opc = "";
        Scanner scanner = new Scanner(System.in);

        // Configuração fixa para testar
        boolean usarValoresFixos = false; // Altere para false se quiser usar entrada manual

        long getCapacidadeMax;
        ArrayList<Produto> itens = new ArrayList<>();

        if (usarValoresFixos) {
            System.out.println("Usando valores fixos para teste...");
            getCapacidadeMax = 10; // Capacidade fixa do armazém
            itens.add(new Produto("Produto A", 2, 3));
            itens.add(new Produto("Produto B", 3, 4));
            itens.add(new Produto("Produto C", 4, 5));
            itens.add(new Produto("Produto D", 5, 8));
        } else {
            System.out.println("Qual o tamanho do armazém?");
            getCapacidadeMax = scanner.nextLong();
            scanner.nextLine();

            System.out.println("Deseja criar os itens manualmente?");
            opc = scanner.nextLine().toUpperCase();

            if (opc.equals("SIM")) {
                String adicionarMais = "sim";
                while (adicionarMais.equalsIgnoreCase("sim")) {

                    System.out.println("Qual o nome do produto?");
                    String nomeItem = scanner.nextLine();

                    System.out.println("Qual o peso do produto?");
                    long pesoItem = scanner.nextLong();
                    scanner.nextLine();

                    System.out.println("Qual o valor do produto?");
                    long valorItem = scanner.nextLong();
                    scanner.nextLine();

                    Produto produto = new Produto(nomeItem, pesoItem, valorItem);
                    itens.add(produto);

                    System.out.println("Deseja adicionar mais itens? (sim/não)");
                    adicionarMais = scanner.nextLine();
                }
            } else {
                System.out.println("Quantos itens deseja gerar?");
                int qntd = scanner.nextInt();
                scanner.nextLine();

                System.out.println("Deseja usar uma seed?");
                String usarSeed = scanner.nextLine().toUpperCase();

                GeradorDeItens gerador;

                if (usarSeed.equals("SIM")) {
                    System.out.println("Qual a seed?");
                    int seed = scanner.nextInt();
                    scanner.nextLine();

                    gerador = new GeradorDeItens(seed);
                } else {
                    gerador = new GeradorDeItens();
                }

                itens = gerador.gerarItensAleatorios(qntd);
            }
        }

        System.out.println("\nItens Criados:");
        for (Produto item : itens) {
            System.out.println(item);
        }

        AEstrela mochilaAEstrela = new AEstrela(getCapacidadeMax, itens);
        Armazem armazemPerfeito = mochilaAEstrela.resolver();

        System.out.println("\nResultado da Mochila:");
        System.out.println("Capacidade Máxima: " + armazemPerfeito.getCapacidadeMax());
        System.out.println("Itens Selecionados:");
        for (Produto item : armazemPerfeito.getItens()) {
            System.out.println(item);
        }

        scanner.close();
    }
}
